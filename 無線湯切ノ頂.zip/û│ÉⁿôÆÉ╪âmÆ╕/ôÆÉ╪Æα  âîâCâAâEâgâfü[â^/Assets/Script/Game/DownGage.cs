﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DownGage : MonoBehaviour
{
    public GameObject gameObject;

    SerialHandler SerialHandler_;
    public AudioSource fin;
    public AudioSource SE;
    float timer = 0.0f;
    public int SkillPoint = 0;
    public GameObject Tenku;
    public Text text;
    public GameObject Canvas;
    Slider _slider;
    public float hp;
    float WaterGage;
    public bool MISS = false;
    public bool CLEAR = false;
    void Start()
    {
        text.color = new Color(0, 0, 0, 0);
        _slider = GameObject.Find("Slider").GetComponent<Slider>();
        hp = 1;
        SerialHandler_ = GameObject.Find("systemManager").GetComponent<SerialHandler>();
    }
    void Update()
    {

        if (gameObject.GetComponent<CountDown>().countBool)
        {

            if (!MISS)
            {
                if (GetComponent<Example>().force >= 5.0f&& GetComponent<Example>().force != 0.0f)
                {
                    SE.Play();
                    if (GetComponent<Example>().force >= 30.0f)
                    {
                        TenkuOtoshi(GetComponent<Example>().force);
                    }
                    else
                    {
                        hp -= (GetComponent<Example>().force) * 0.01f;

                    }
                }
               
            }

            if (hp <= 0 && !MISS)
            {
                if (!CLEAR)
                {
                    fin.Play();
                }
                CLEAR = true;
                text.color = new Color(0, 0, 0, 1);
                text.text = "終了!";
                timer += Time.deltaTime;
                if (timer > 3.0f)
                {
                    //SerialHandler_.Close();
                    SceneManager.LoadScene("Score");
                }
            }
            if (Input.GetKey(KeyCode.KeypadEnter))
            {
                MISS = true;
                fin.Play();
            }

            if (MISS)
            {
                text.color = new Color(0, 0, 0, 1);
                text.text = "麺をこぼしたな？失格！！";
                timer += Time.deltaTime;
                if (timer > 3.0f)
                {
                  //  SerialHandler_.Close();
                    WaterGage = 0;
                    gameObject.GetComponent<rankingSystem>().SetWaterGage(WaterGage);
                    SceneManager.LoadScene("Score");
                }
            }
            if ((int)(gameObject.GetComponent<CountDown>().timer * 100) / 100.0f >= 15.0f)
            {
                if (!MISS)
                {
                    fin.Play();
                }
                MISS = true;
                text.color = new Color(0, 0, 0, 1);
                text.text = "湯切失敗...";
                timer += Time.deltaTime;
                if (timer > 3.0f)
                {
                   // SerialHandler_.Close();
                    WaterGage = (100 - 100 * hp);
                    gameObject.GetComponent<rankingSystem>().SetWaterGage(WaterGage);
                    SceneManager.LoadScene("Score");
                }
            }
        }
        _slider.value = hp;
    }
    void TenkuOtoshi(float force)
    {
        if (!GameObject.Find("Tenku(Clone)") && hp > 0)
        {
            GameObject prefab = (GameObject)Instantiate(Tenku);
            SkillPoint += (int)(GetComponent<Example>().force) * 10;
            prefab.transform.SetParent(Canvas.transform, false);
            hp =0.0f ;
        }
    }
}