﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GageText : MonoBehaviour
{
    public GameObject WaterGage;
    public Text text;
    void Start()
    {
        text.text = WaterGage.GetComponent<Example>().water.ToString();
    }
    void Update()
    {
        if ((int)(WaterGage.GetComponent<Example>().water)>=0) {
            {
                text.text =((int)(WaterGage.GetComponent<Example>().water)).ToString();
            }
        }
        if (WaterGage.GetComponent<Example>().CLEAR)
        {
            text.text = "0";
        }
    }
}