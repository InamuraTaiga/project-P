﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

public class CountDown : MonoBehaviour {
    public Text text;
    public Text time;
    public Image GameStart;
    int Count = 4;
    float count = 4.0f;
    float a;
    public float timer = 15.0f;
    public bool countBool = false;
    public GameObject gameObject;
    float r, g, b;
    // Use this for initialization
    void Start()
    {
        text.text = Count.ToString();
        time.text = "15.0";
        r = GameStart.color.a;
        g = GameStart.color.g;
        b = GameStart.color.b;
        GameStart.color=new Color(r,g,b,0);
    }

    // Update is called once per frame
    void Update()
    {
        if (gameObject.GetComponent<DownGage>().hp > 0&& !gameObject.GetComponent<DownGage>().MISS)
        {
            if (!countBool)
            {
                if (count > 0.0f)
                {
                    count -= Time.deltaTime;
                    text.text = ((int)count).ToString();
                    if (text.text == "0")
                    {
                        a = 1.0f;
                        GameStart.color = new Color(r, g, b, a);
                        text.text = "";
                    }
                }
                else
                {
                    countBool = true;
                }
            }
            else
            {
                if (!gameObject.GetComponent<DownGage>().MISS)
                {

                    a -= 0.02f;
                    GameStart.color = new Color(r,g, b, a);
                    timer += Time.deltaTime;
                    time.text =   ((int)((15 - timer) * 100) / 100.0f).ToString();
                    if (timer >= 15.0f)
                    {
                        time.text = "0";
                    }
                }
                else
                {
                    a -= 0.02f;
                    GameStart.color = new Color(r, g, b, a);
                }
              
            }

        }
        else
        {
            time.text = "";

        }
    }
}
