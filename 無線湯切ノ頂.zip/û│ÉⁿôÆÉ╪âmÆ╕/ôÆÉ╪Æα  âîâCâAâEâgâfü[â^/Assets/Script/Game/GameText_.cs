﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GameText_ : MonoBehaviour
{
    rankingSystem rankingSystem_;
    public GameObject Gage;
    public GameObject gm;
    bool Save = false;
    float time;
    float WaterGage;
    public int dScore;
    // Use this for initialization
    void Start()
    {        
        rankingSystem_ = GameObject.Find("GameManager").GetComponent<rankingSystem>();//いつもの
    }

    // Update is called once per frame
    void Update()
    {
        if (Gage.GetComponent<DownGage>().hp <= 0.0f && !Save)
        {
            time = gm.GetComponent<CountDown>().timer;
            int Score = Gage.GetComponent<DownGage>().SkillPoint;
            dScore = Score;
            if (Gage.GetComponent<DownGage>().hp < 0.0f)
            {
                WaterGage = 100;
            }
            else
            {
                WaterGage = 100 - 100 * Gage.GetComponent<DownGage>().hp;
            }
            Score = Score + (int)((16.0f - time+10.0f) * WaterGage);
            rankingSystem_.rankingUpdate(Score, WaterGage);//順位、参加者、得点の更新
            Save = true;
            rankingSystem_.rankingDateSave();//テキストとしてデータの保存する関数
            rankingSystem_.SetTime(time);
            rankingSystem_.SetScore(dScore);

        }
        if (gm.GetComponent<CountDown>().timer >= 15.0f && !Save)
        {
            time = gm.GetComponent<CountDown>().timer;
            int Score = Gage.GetComponent<DownGage>().SkillPoint;
            dScore = Score;
            WaterGage = 100 - 100 * Gage.GetComponent<DownGage>().hp;
            Score = (int)(Score + WaterGage*10);
            rankingSystem_.rankingUpdate(Score, WaterGage);//順位、参加者、得点の更新
            Save = true;
            rankingSystem_.rankingDateSave();//テキストとしてデータの保存する関数
            rankingSystem_.SetTime(time);
            rankingSystem_.SetScore(dScore);
        }
        if (Gage.GetComponent<DownGage>().MISS && !Save && gm.GetComponent<CountDown>().timer >= 0.0f)
        {
            time = gm.GetComponent<CountDown>().timer;
            int Score = Gage.GetComponent<DownGage>().SkillPoint;
            dScore = Score;
            WaterGage = 100 - 100 * Gage.GetComponent<DownGage>().hp;
             Score = Score + (int)(time * WaterGage);
            rankingSystem_.rankingUpdate(Score, WaterGage);//順位、参加者、得点の更新
            Save = true;
            rankingSystem_.rankingDateSave();//テキストとしてデータの保存する関数
            rankingSystem_.SetTime(time);
            rankingSystem_.SetScore(dScore);
        }

        //----------------------------ゲーム終了の一連処理へ----------------------------
        if (Input.GetKey(KeyCode.Escape))
        {
            rankingSystem_.rankingDateSave();//テキストとしてデータの保存する関数
            Debug.Log("rankingDateSave & gameFinish");
            rankingSystem_.Quit();//ゲームを終了させる関数
        }
        //----------------------------ゲーム終了の一連処理へ----------------------------
    }
}
