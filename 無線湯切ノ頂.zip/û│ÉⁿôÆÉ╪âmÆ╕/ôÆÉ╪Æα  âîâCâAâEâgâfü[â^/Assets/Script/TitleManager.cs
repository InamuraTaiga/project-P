﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TitleManager : MonoBehaviour {
    public Image back;
    public GameObject paper;
    bool Tap = false;
    bool MusicStart = false;
    public AudioSource start;
    public AudioSource Music;
    enum STEP
    {
        TITLE,
        GAME,
    }
    Color now;
    Color pnow;
    STEP step;
    // Use this for initialization
    void Start () {
        step = STEP.TITLE;
        now = back.color;
    }

    // Update is called once per frame
    void Update() {
        switch (step)
        {
            case STEP.TITLE:
                if (!MusicStart)
                {
                    MusicStart = true;
                    Music.Play();
                }
                //if (Input.GetKeyDown("space")&&!Tap)

                if (Input.GetKey(KeyCode.KeypadEnter))
                {
                    Music.Pause();
                    start.Play();
                    DestroyObject(paper, 0.0f);
                    Tap = true;
                }
                if (Tap)
                {
                    float a = now.a - 0.005f;
                    if (a < 0)
                    {
                        a = 0;
                    }
                    now.a = a;
                    back.color = new Color(now.r, now.g, now.b, a);
                }
                if (now.a == 0.0f)
                {
                    step = STEP.GAME;
                }
                break;
            case STEP.GAME:
                SceneManager.LoadScene("Game");
                break;
        }
	}
}
