﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ResultManager : MonoBehaviour {
    public GameObject gm;
    public Text ScoreText;
    public Text numberText;
    public Text Player;
    public Text RankInAllPlayer;
    public Text Gage;
    float timer = 5.0f;
    int number;
    int Score;
    int PlayerNumber;
    // Use this for initialization
    void Start()
    {
        if (gm.GetComponent<rankingSystem>().GetWaterGage() >= 100.0f)
        {
            number = gm.GetComponent<rankingSystem>().getRankingNumber();
            Score = gm.GetComponent<rankingSystem>().getPlayerScore();
            PlayerNumber = gm.GetComponent<rankingSystem>().getRankingAllParticipants();
            RankInAllPlayer.text = "上位" + ((float)number / (float)PlayerNumber * 100).ToString() + "%";
            Player.text = "参加者:" + PlayerNumber.ToString()+"名";
            ScoreText.text = "Score:" + Score.ToString();
            numberText.text = "Rank:" + number.ToString();
        }else
        {
            number = gm.GetComponent<rankingSystem>().getRankingNumber();
            Score = gm.GetComponent<rankingSystem>().getPlayerScore();
            PlayerNumber = gm.GetComponent<rankingSystem>().getRankingAllParticipants();
            RankInAllPlayer.text = "上位" + ((float)number / (float)PlayerNumber * 100).ToString() + "%";
            Player.text = "参加者:" + PlayerNumber.ToString() + "名";
            ScoreText.text = "Score:" + Score.ToString();
            numberText.text = "Rank:" + number.ToString();
            Gage.text = "残念...。\n"+gm.GetComponent<rankingSystem>().GetWaterGage().ToString()+"%水分が残ってしまいました。";
        }
    }
	
	// Update is called once per frame
	void Update () {
        timer -= Time.deltaTime;

        if (timer < 0.0f)
        {
            SceneManager.LoadScene("title");
        }
	}
}
