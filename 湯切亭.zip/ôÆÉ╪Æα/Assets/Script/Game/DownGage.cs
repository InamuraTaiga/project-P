﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DownGage : MonoBehaviour
{
    public GameObject gameObject;
    float timer = 0.0f;
    public int SkillPoint;
    public Text text;
    Slider _slider;
    public float hp;
    float WaterGage;
    public bool MISS = false;
    void Start()
    {
        text.color = new Color(0, 0, 0, 0);
        _slider = GameObject.Find("Slider").GetComponent<Slider>();
        hp = 1;

    }
    void Update()
    {
        if (gameObject.GetComponent<CountDown>().countBool)
        {

            if (Input.GetKeyDown("a") && !MISS)
            {
                hp -= 0.1f;
                SkillPoint += Random.RandomRange(1, 10);
            }

            if (hp < 0&&!MISS)
            {
                text.color = new Color(0, 0, 0, 1);
                text.text = "終了!";
                timer += Time.deltaTime;
                if (timer > 3.0f)
                {
                    SceneManager.LoadScene("result");
                }
            }
            if ((int)(gameObject.GetComponent<CountDown>().timer * 100) / 100.0f>=15.0f)
            {
                MISS = true;
                text.color = new Color(0, 0, 0, 1);
                text.text = "湯切り失敗...";
                timer += Time.deltaTime;
                if (timer > 3.0f)
                {
                    WaterGage = (100 - 100 * hp);
                    gameObject.GetComponent<rankingSystem>().SetWaterGage(WaterGage);
                    SceneManager.LoadScene("result2");
                }
            }
        }
        _slider.value = hp;
    }
}