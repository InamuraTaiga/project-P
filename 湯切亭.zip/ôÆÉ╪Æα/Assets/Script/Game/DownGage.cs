﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DownGage : MonoBehaviour
{
    public GameObject gameObject;
    float timer = 0.0f;
    public int SkillPoint;
    public Text text;
    Slider _slider;
    public float hp;
    void Start()
    {
        text.color = new Color(0, 0, 0, 0);
        _slider = GameObject.Find("Slider").GetComponent<Slider>();
        hp = 1;

    }
    void Update()
    {
        if (gameObject.GetComponent<CountDown>().countBool)
        {

            if (Input.GetKeyDown("a"))
            {
                hp -= 0.1f;
                SkillPoint += Random.RandomRange(1, 10);
            } 

            if (hp < 0)
            {
                text.color = new Color(0, 0, 0, 1);
                text.text = "終了!";
                timer += Time.deltaTime;
                if (timer > 3.0f)
                {
                    SceneManager.LoadScene("result");
                }
            }
        }
        _slider.value = hp;
    }
}