﻿using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class rankingSystem : MonoBehaviour {
    private static int startCount=0; 
    private string loadText;
    private string[] splitText;
    private static List<int> rankingScore_=new List<int>();
    private static int rankingNumber;
    private static int playerScore;
    private static float WaterGage; 

    public int testScore;

    

    public void rankingUpdate(int score,float Gage)//ランキングの更新
    {
        int number = 0;
        if (rankingScore_[rankingScore_.Count - 1] > score)
        {
            rankingScore_.Add(score);
            number = rankingScore_.Count - 1;
        }
        else
        {
            for (int i = 0; i < rankingScore_.Count; i++)
            {
                if (rankingScore_[i] < score)
                {
                    rankingScore_.Insert(i, score);
                    number = i;
                    break;
                }
            }
        }
        setRankingNumber(number);
        SetWaterGage(Gage);
        setPlayerScore(score);
    }

    public void SetWaterGage(float Gage)
    {
        WaterGage = Gage;
    }
    public int GetWaterGage()
    {
        return (int)WaterGage;
    }
    public void setRankingNumber(int number)//今プレイした順位を保存
    {
        rankingNumber = number;
    }
    public int getRankingNumber()//今プレイした順位を受け渡し
    {
        return rankingNumber+1;
    }

    public int getRankingAllParticipants()//ランキング参加者数を受け渡し
    {        
        return rankingScore_.Count;
    }

    public void rankingDateSave()
    {
        string unitText = "";
        for (int i = 0; i <rankingScore_.Count;i++)
        {
            unitText += rankingScore_[i];
            if (i < rankingScore_.Count - 1) unitText += "\n";
        }

        var path = Application.streamingAssetsPath + "/rankingScore.txt";

        StreamWriter output;
        output = new StreamWriter(path, false);
        //output = new StreamWriter(Application.dataPath + "/Resources/rankingContent/rankingScore.txt", false);
        output.Write(unitText);
        output.Flush();
        output.Close();

    }

    void setPlayerScore(int score)
    {
        playerScore = score;
    }
    public int getPlayerScore()
    {
        return playerScore;
    }

   public void Quit()
    {
#if UNITY_STANDALONE
        Application.Quit();
#endif

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }

    public void dateResetForDebug()
    {
        var path = Application.streamingAssetsPath + "/rankingScore.txt";

        StreamWriter output;
        output = new StreamWriter(path, false);
        output.Write("0");
        output.Flush();
        output.Close();

        Quit();

        Debug.Log("ScoreDateをリセットしました。\n強制終了します");

    }

    void Start () {

        if (startCount == 0) { 
            var path = Application.streamingAssetsPath + "/rankingScore.txt";
            loadText = File.ReadAllText(path);
            splitText = loadText.Split(char.Parse("\n"));
            for (int i = 0; i < splitText.Length; i++)
            {
                rankingScore_.Add(int.Parse(splitText[i]));
            }
            startCount++;

            rankingNumber = 0;
        }else
        {
            //Debug.Log("textLoadの処理を飛ばしました。");
        }
	}

	
}
