﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GameText_ : MonoBehaviour
{
    rankingSystem rankingSysytem_;
    public GameObject Gage;
    public GameObject gm;
    bool Save = false;

    // Use this for initialization
    void Start()
    {        
        rankingSysytem_ = GameObject.Find("GameManager").GetComponent<rankingSystem>();//いつもの

    }

    // Update is called once per frame
    void Update()
    {
        if (Gage.GetComponent<DownGage>().hp < 0.0f && !Save)
        {
            int Score = Gage.GetComponent<DownGage>().SkillPoint;
            float WaterGage = 100 - 100 * Gage.GetComponent<DownGage>().hp;
            rankingSysytem_.rankingUpdate(Score, WaterGage);//順位、参加者、得点の更新
            Save = true;
            rankingSysytem_.rankingDateSave();//テキストとしてデータの保存する関数
        }
        if (gm.GetComponent<CountDown>().timer >= 15.0f && !Save)
        {
            int Score = Gage.GetComponent<DownGage>().SkillPoint;
            float WaterGage = 100 - 100 * Gage.GetComponent<DownGage>().hp;
            rankingSysytem_.rankingUpdate(Score, WaterGage);//順位、参加者、得点の更新
            Save = true;
            rankingSysytem_.rankingDateSave();//テキストとしてデータの保存する関数
        }


        //----------------------------ゲーム終了の一連処理へ----------------------------
        if (Input.GetKey(KeyCode.Escape))
        {
            rankingSysytem_.rankingDateSave();//テキストとしてデータの保存する関数
            Debug.Log("rankingDateSave & gameFinish");
            rankingSysytem_.Quit();//ゲームを終了させる関数
        }
        //----------------------------ゲーム終了の一連処理へ----------------------------
    }
}
