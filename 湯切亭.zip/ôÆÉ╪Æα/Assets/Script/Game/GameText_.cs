﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GameText_ : MonoBehaviour
{
    rankingSystem rankingSysytem_;
    public GameObject Gage;
    bool Save = false;

    // Use this for initialization
    void Start()
    {        
        rankingSysytem_ = GameObject.Find("GameManager").GetComponent<rankingSystem>();//いつもの

    }

    // Update is called once per frame
    void Update()
    {
        if (Gage.GetComponent<DownGage>().hp < 0.0f)
        {
            if (!Save)
            {
                int Score = Gage.GetComponent<DownGage>().SkillPoint;
                rankingSysytem_.rankingUpdate(Score);//順位、参加者、得点の更新
                Debug.Log("Score:" + Score);
                Save = true;
                rankingSysytem_.rankingDateSave();//テキストとしてデータの保存する関数
            }
        }
        //----------------------------ゲーム終了の一連処理へ----------------------------
        if (Input.GetKey(KeyCode.Escape))
        {
            rankingSysytem_.rankingDateSave();//テキストとしてデータの保存する関数
            Debug.Log("rankingDateSave & gameFinish");
            rankingSysytem_.Quit();//ゲームを終了させる関数
        }
        //----------------------------ゲーム終了の一連処理へ----------------------------
    }
}
