﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;

public class CountDown : MonoBehaviour {
    public Text text;
    public Text time;
    int Count = 4;
    float count = 4.0f;
    float a = 1.0f;
    public float timer = 0.0f;
    public bool countBool = false;
    public GameObject gameObject;
    // Use this for initialization
    void Start()
    {
        text.text = Count.ToString();
        time.text = "経過時間:0.0";
    }

    // Update is called once per frame
    void Update()
    {
        if (gameObject.GetComponent<DownGage>().hp >= 0)
        {
            if (!countBool)
            {
                if (count > 0.0f)
                {
                    count -= Time.deltaTime;
                    text.text = ((int)count).ToString();
                    if (text.text == "0")
                    {
                        text.text = "湯切り開始!";
                    }
                }
                else
                {
                    countBool = true;
                }
            }
            else
            {
                if (!gameObject.GetComponent<DownGage>().MISS)
                {

                    a -= 0.02f;
                    text.color = new Color(0, 0, 0, a);
                    timer += Time.deltaTime;
                    time.text = "経過時間:" + ((int)(timer * 100) / 100.0f).ToString();
                }
            }

        }
    }
}
