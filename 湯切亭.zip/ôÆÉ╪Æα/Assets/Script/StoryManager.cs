﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StoryManager : MonoBehaviour {
    public Text text1;
    public Text text2;
    string[] text;
    int count = 0;
    float timer = 0.0f;
    void Start()
    {
        text = new string[4];
        text[0] = "店長：ようこそ、新人さん。";
        text[1] = "早速だけど仕事を覚えてもらうよ。";
        text1.text = text[0];
        text2.text = text[1];
        text[2] = "店長：じゃあ今日は湯切りをやってこうか。";
        text[3] = "麺をこぼさないように気を付けてね。";
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= 4.0f)
        {
            text1.text = text[2];
            text2.text = text[3];
        }
        if (timer >= 8.0f)
        {
            SceneManager.LoadScene("game");
        }
    }
}
